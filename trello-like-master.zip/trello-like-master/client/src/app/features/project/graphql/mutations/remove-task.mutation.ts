import { Injectable } from '@angular/core'
import { gql, Mutation } from 'apollo-angular'
import { Task } from './../../../../models/task.model'

@Injectable({
  providedIn: 'root',
})
export class RemoveTaskGQL extends Mutation<
  { removeTask: Task },
  { id: string }
> {
  document = gql`
    mutation RemoveTask($id: ID!) {
      removeTask(id: $id) {
        id
      }
    }
  `
}
