import { Injectable } from '@angular/core'
import { gql, Query } from 'apollo-angular'
import { Task } from './../../../../models/Task.model'

@Injectable({
  providedIn: 'root',
})
export class TasksGQL extends Query<{ tasks: Task[] }> {
  document = gql`
    query {
       
        tasks {
          id
          name
        }
      
    }
  `
}
