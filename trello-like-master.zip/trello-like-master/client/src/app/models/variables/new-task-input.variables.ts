import { Task } from '../task.model';

export interface NewTaskInputVariables {
  input: Task;
}
