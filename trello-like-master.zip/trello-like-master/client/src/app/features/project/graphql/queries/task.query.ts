import {Query, gql} from 'apollo-angular';
import { Injectable } from '@angular/core';


import { TaskResponse } from 'src/app/models/task.model';

@Injectable({
  providedIn: 'root'
})
export class TaskByIdGQL extends Query<TaskResponse, {id: string}> {
  document = gql`
    query GetTask($id: ID!){
      Task(id: $id) {
        name
        id
      }
    }`;
}
