module.exports = {
  client: {
    service: {
      url: 'http://localhost:3001/graphql',
    },
  },
}
